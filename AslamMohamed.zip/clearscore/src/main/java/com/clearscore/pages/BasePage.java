package com.clearscore.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

/**
 * @author Ash
 *This Base class is to keep the common property file and initiating different browser drivers for all the tests
 */
public class BasePage {

	protected WebDriver driver = getDriver();
	private String browser;
	protected String baseUrl;
	
	//public BasePage() {
	//driver = getDriver();
	//}
	/**
	 * This method constructs the webdriver and returns the instance of driver. 
	 * @return WebDriver
	 */
	public WebDriver getDriver() {
		loadProperties();
		browser = System.getProperty("browser");
		baseUrl = System.getProperty("baseUrl");
		driver = null;
		if (browser.equalsIgnoreCase("Firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\Software\\geckodriver.exe");
		      driver = new FirefoxDriver();
		} else if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "chromedriver");
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("ie")) {
			System.setProperty("webdriver.ie.driver", "C:\\Software\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		} else {
			System.out.println("The browser "+browser+"is not defined");
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		return driver;
	}
	
	/**
	 * This method loads custom properties to system environment and returns the 
	 * full list of all properties currently set.
	 * @return Properties
	 */
	private Properties loadProperties() {
		Properties properties = System.getProperties();
		File file = new File("src//test//resources//common.properties");
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException e1) {
			System.out.println("File not found at specified location");
			e1.printStackTrace();
		}
		try {
			properties.load(fis);
		} catch (IOException e) {
			System.out.println("File not found ");
			e.printStackTrace();
		}
		return properties;
	}
	
	/**
	 * Quit the browser
	 */
	public void closeBrowser() {
		driver.quit();
	}
}
