package com.clearscore.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author Ash
 *
 */
public class SavingsCalculatorPage extends BasePage {

	public SavingsCalculatorPage() {
		driver.navigate().to(baseUrl+"/savings-calculator");
		WebElement weUseCookeis = driver.findElement(By.className("accept-cookies"));
		if(weUseCookeis.isDisplayed()) {
			weUseCookeis.click();
		}
	}
	/**
	 *  This method move CurrentScore slider to 50
	 */
	public void moveYourCurrentScoreSliderTo50() {
		Actions builder = new Actions(driver);
		builder.moveToElement(getCreditCardsAvailable()).click()
		.dragAndDropBy(getYourCurrentScoreSlider(),-237, 0)
		.build()
		.perform();
	}
    
	/**
	 *  This method move GoalScore slider to 680
	 * @throws InterruptedException 
	 */
	public void moveYourScoreGoalSliderTo680() throws InterruptedException  {
		Actions builder = new Actions(driver);
		builder.moveToElement(getCreditCardsAvailable()).click()
		.dragAndDropBy(getYourScoreGoalSlider(),261, 0)
		.build()
		.perform();

	}

	private WebElement findElement(By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		return wait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	
	/**
	 * @return the yourCurrentScore webelement
	 */
	public WebElement getYourCurrentScoreSlider() {
		WebElement yourCurrentScore = findElement(By.className("js-range-current"));
		return yourCurrentScore;
	}
	/**
	 * @return the resultsTable webelement
	 */
	private WebElement getResultsTable() {
		WebElement resultsTable = findElement(By.className("cs-scalc__table-el"));
		return resultsTable;
	}

	/**
	 * @return the creditCardsAvailable webelement
	 */
	private WebElement getCreditCardsAvailable() {
		WebElement creditCardsAvailable = findElement(By.className("cs-scalc__table-el")).findElements(By.tagName("tr")).get(2);
		return creditCardsAvailable;
	}

	/**
	 * @return the yourCurrentScoreValue value
	 */
	public String getYourCurrentScoreValue() {
		WebElement yourCurrentScoreValue = findElement(By.className("js-range-current-val"));
		return yourCurrentScoreValue.getText();
	}

	/**
	 * @return the yourScoreGoalValue value
	 */
	public String getYourScoreGoalValue() {
		WebElement yourScoreGoalValue = findElement(By.className("js-range-goal-val"));
		return yourScoreGoalValue.getText();
	}
	
	/**
	 * @return the yourGolaScoreSlider webelement
	 */
	public WebElement getYourScoreGoalSlider() {
		WebElement yourScoreGoalSlider = findElement(By.className("js-range-goal"));
		return yourScoreGoalSlider;
	}
	
	/**
	 * @param rowNo
	 * @param columnNo
	 * @return value from table at given rowNo and columnNo
	 */
	private String getData (int rowNo,int columnNo) {
		return getResultsTable().findElements(By.tagName("tr")).get(rowNo).findElements(By.tagName("td")).get(columnNo).getText();
	}
	
	/**
	 * @return average interest rate value for Current from table
	 */
	public String getCurrentAverageInterestRate() {
		return getData(1, 1);
	}
	
	/**
	 * @return annual cost value for Current from table
	 */
	public String getCurrentAnnualCost() {
		return getData(2, 1);
	}
	
	/**
	 * @return CreditCards available value for Current from table
	 */
	public String getCurrentCreditCardsAvailable() {
		return getData(3, 1);
	}
	
	/**
	 * @return average interest rate value for Goal from table
	 */
	public String getGoalAverageInterestRate() {
		return getData(1, 2);
	}
	
	/**
	 * @return annual cost value for Goal from table
	 */
	public String getGoalAnnualCost() {
		return getData(2, 2);
	}
	
	/**
	 * @return CreditCards available value for Goal from table
	 */
	public String getGoalCreditCardsAvailable() {
		return getData(3, 2);
	}
	
	public String potentialSavingValue() {
		WebElement potentialSaving = driver.findElement(By.className("js-total-saving-value"));
		return potentialSaving.getText();
		
	}
	
}
