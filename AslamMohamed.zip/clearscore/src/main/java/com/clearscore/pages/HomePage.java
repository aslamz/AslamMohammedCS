package com.clearscore.pages;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebElement;

public class HomePage extends BasePage {

	private WebElement weUseCookies;

	public HomePage() {
		driver.navigate().to(baseUrl);

		weUseCookies = driver.findElement(By.className("accept-cookies"));
	}

	/**
	 * @return weUseCookies webelement
	 */
	public WebElement getWeUseCookies() {
		return weUseCookies;
	}

	/**
	 * Dismissing the "We use cookies" notification
	 */
	public void dismissWeUseCookiesNotification() {
		getWeUseCookies().click();
	}

	/**
	 * @return all cookies currently set on this page
	 */
	public Set<Cookie> getAllCookes() {
		return driver.manage().getCookies();
	}

}
