package com.clearscore.tests;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import com.clearscore.pages.HomePage;

/**
 * @author Ash
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CookiesNotificationTest {
	static HomePage homePage;
	
	@BeforeClass
	public static void setUp() {
		homePage = new HomePage();
	}
	
	@AfterClass
	public static void tearUp() {
		homePage.closeBrowser();
	}
	
	/**
	 * Verifying whether "We use cookies notification" present.
	 */
	@Test ()
	public void checkWeUseCookiesNotificationPresent() {
		Assert.assertTrue(homePage.getWeUseCookies().isDisplayed());
	}
	
	/**
	 * dismissing "We use cookies notification" present and verifying whether it is dismissed.
	 */
	@Test
	public void dismissWeUseCookiesNotification() {
		homePage.dismissWeUseCookiesNotification();
		Assert.assertFalse(homePage.getWeUseCookies().isDisplayed());
	}
	
	/**
	 * Verifying that "We use cookies" notification is not present any more once dismissed.
	 */
	@Test
   public void verifyWeUseCookiesNotPresentAnymore() {
		Assert.assertFalse(homePage.getWeUseCookies().isDisplayed());
   }
	
	/**
	 * Verifying how many cookies are currently available after "We use notification" dismissed.
	 */
	@Test
	public void verifyCookiesSet() {
		Assert.assertEquals(21,homePage.getAllCookes().size());
	}
}
