package com.clearscore.tests;

import static io.restassured.RestAssured.given;

import java.util.UUID;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

/**
 * @author Ash
 *
 */
public class ApiTest {

	/**
	 * This test validates http status code when log in details are incorrect. the expected status code is 403
	 */
	@Test
	public void testHttp403WhenInvalidCredentailsProvided() {
		int expectedStatusCode = 403;
		RestAssured.baseURI = "https://api.clearscore.com";
		JSONObject requestParams = new JSONObject();
		requestParams.put("email", "aslamz@live.co.uk");
		requestParams.put("password", "helloWorld");
		requestParams.put("password", "helloWorld");
		Response response = given()
				.header("Content-Type", "application/json")
				.header("device", "desktop")
				.body(requestParams.toString())
				.when().post("/caesium-api/users/signIn");
		int actualStatusCode = response.getStatusCode();
		Assert.assertEquals(expectedStatusCode, actualStatusCode);
	}

}
