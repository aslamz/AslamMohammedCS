package com.clearscore.tests;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.clearscore.pages.SavingsCalculatorPage;

public class CalculatorTests {

	static SavingsCalculatorPage savingsCalculatorPage;

	@BeforeClass
	public static void setUP() {
		savingsCalculatorPage = new SavingsCalculatorPage();
	}

	@AfterClass
	public static void tearDown() {
		savingsCalculatorPage.closeBrowser();
	}

	/**
	 * Test 3 On the ClearScore savings calculator
	 * (https://www.clearscore.com/savings-calculator/), write tests to check that:
	 * When updating your current score to 50, and score goal to 680 that ? Your
	 * current score interest rate, costs, and cards available are: 36.5%, ?849, and
	 * 22 Your score goal interest rate, costs, and cards available are: 20%, ?465,
	 * and 241 Your potential savings are ?384
	 * @throws InterruptedException 
	 */
	@Test
	public void savingsCalculatorTest() throws InterruptedException {
		String expectedcurrentAverageInterestRate = "36.5%";
		String expectedCurrentAnnualCost = "�849";
		String expectedCurrentCreditCardsAvailable = "22";

		String expectedGoalAverageInterestRate = "20%";
		String expectedGoalAnnualCost = "�465";
		String expectedGoalCreditCardsAvailable = "241";
		String expectedPotentailSavingValue = "384";

		savingsCalculatorPage.moveYourCurrentScoreSliderTo50();
		savingsCalculatorPage.moveYourScoreGoalSliderTo680();

		Assert.assertEquals(expectedcurrentAverageInterestRate, savingsCalculatorPage.getCurrentAverageInterestRate());
		Assert.assertEquals(expectedCurrentAnnualCost, savingsCalculatorPage.getCurrentAnnualCost());
		Assert.assertEquals(expectedCurrentCreditCardsAvailable,
				savingsCalculatorPage.getCurrentCreditCardsAvailable());

		Assert.assertEquals(expectedGoalAverageInterestRate, savingsCalculatorPage.getGoalAverageInterestRate());
		Assert.assertEquals(expectedGoalAnnualCost, savingsCalculatorPage.getGoalAnnualCost());
		Assert.assertEquals(expectedGoalCreditCardsAvailable, savingsCalculatorPage.getGoalCreditCardsAvailable());
		Assert.assertEquals(expectedPotentailSavingValue, savingsCalculatorPage.potentialSavingValue());
	}
}
